//app.js
import {decrypt,encrypt} from './js/sm4crypt.js'
import {randomRange} from './js/random.js'
const sm2 = require('./js/miniprogram-sm-crypto/index.js').sm2;
const cipherMode = 0; // 1 - C1C3C2，0 - C1C2C3，默认为1
let keypair = sm2.generateKeyPairHex();
const app = getApp();
var rand03 = randomRange(32);
var data = {
  addTime: null,
  amount: 100010,
  nickname: "张三丰",
  arrau:[{name:'zhangsan',age:14},{name:'lisi',age:20}]
}
const msgString = JSON.stringify(data)
  var publicKey = keypair.publicKey; // 公钥
    var privateKey = keypair.privateKey; // 私钥
    console.log('sm2公钥')
    console.log(publicKey)
    console.log('sm2私钥')
    console.log(privateKey)
    // var pub = '42930d1c6e1cdd6d4ddd10c2508886100b35d7dffd402ff2b36db67f68469e10'
    let encryptData = sm2.doEncrypt(msgString, publicKey, cipherMode); // 加密结果
    let decryptData = sm2.doDecrypt(encryptData, privateKey, cipherMode); // 解密结果
    console.log('sm2加密')
    console.log(encryptData)
    console.log('sm2解密')
    console.log(decryptData)
    // var key = 'CCB545A588D21C94C8749C0D4528A79F'
    // CCBADCCCDAF 545794528087499421588
    // var key = '21878A79FCCB545A549C0D4C94C5288D'
    // var key =  generateKey().toString();
    var key =rand03.toUpperCase().toString()
    console.log('sm4密钥长度')
    console.log(key.length)
    console.log('sm4密钥')
    console.log(key)
    console.log('sm4加密')
    console.log(encrypt(key,data))
    var sm4jaimi = encrypt(key,data)
    var newdata = decrypt(key,sm4jaimi)
    // console.log(decrypt(key,'083A5BCCBFBBD7AC9AD61B91261E998883B9658005C1E4F9BC45962359F18238A95264478ACE067C639128D523A3583F12E99E26E4C9C6EE365312213A63A82F'))
    console.log('sm4解密')
    console.log(newdata)
App({
  onLaunch: function () {
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              // 可以将 res 发送给后台解码出 unionId
              this.globalData.userInfo = res.userInfo

              // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
              // 所以此处加入 callback 以防止这种情况
              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            }
          })
        }
      }
    })
  },
  globalData: {
    userInfo: null
  }
})