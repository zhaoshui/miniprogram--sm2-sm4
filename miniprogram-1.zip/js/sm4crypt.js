import {Hex} from './utils/hex.js'
import {SM4} from './crypto/sm4-1.0.js'

// import {SecureRandom} from './ext/rng.js'
// import {BigInteger} from './ext/jsbn2.js'
// 加密
export function encrypt(sm4key,sm4data){
  // var inputtext = sm4data
  var inputtext = JSON.stringify(sm4data)
  var inputBytes = Hex.utf8StrToBytes(inputtext);
  var keytext = sm4key
  var key = Hex.decode(keytext);
  var sm4 = new SM4();
  var cipher = sm4.encrypt_ecb(key,inputBytes);
  return Hex.encode(cipher,0,cipher.length)
}
// 解密
export function decrypt(sm4key,sm4data){
  var inputtext = sm4data
  var inputBytes = Hex.decode(inputtext);
  var keytext = sm4key
  var key = Hex.decode(keytext);
  var sm4 = new SM4();
  var plain = sm4.decrypt_ecb(key,inputBytes);
  return Hex.bytesToUtf8Str(plain)
}
// 生成密钥
// export function generateKey(){
//   var rng = new SecureRandom();
//   var keyBit = new BigInteger(128, rng);
//   while(keyBit.bitLength() < 128){
//     keyBit = new BigInteger(128, rng);
//   }
//   var key   = ("0000000000" + keyBit.toString(16)).slice(- 128/4);
//   return key.toUpperCase();
// }